/*
 * Readline suport for Gauche
 *
 * By: YOKOTA Hiroshi
 */

#include <gauche.h> /* must include first to support large file (over 2GB) */

#include <stdio.h>
#include <stdlib.h>

#include <gauche/extend.h>

void Scm_Init_readlinelib(ScmModule *module);

void Scm_Init_term__readline(void)
{
    ScmModule *mod;

    /* Register this DSO to Gauche */
    SCM_INIT_EXTENSION(term__readline);

    /* Create "term.readline" module if it doesn't exist yet. */
    mod = SCM_FIND_MODULE("term.readline", SCM_FIND_MODULE_CREATE);

    /* Register stub-generated procedures inside "readline" module */
    Scm_Init_readlinelib(mod);
}

/* end */
