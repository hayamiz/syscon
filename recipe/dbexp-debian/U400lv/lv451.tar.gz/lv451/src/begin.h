/*
 * begin.h
 *
 * All rights reserved. Copyright (C) 1996 by NARITA Tomio
 * $Id: begin.h,v 1.3 2003/11/13 03:08:19 nrt Exp $
 */

#ifndef __BEGIN_H__
#define __BEGIN_H__

#include <import.h>
#include <boolean.h>

#ifdef  public
#undef	public
#endif  /* public */

#define	public

#endif /* __BEGIN_H__ */
