/*
 * boolean.h
 *
 * All rights reserved. Copyright (C) 1996 by NARITA Tomio
 * $Id: boolean.h,v 1.4 2004/01/05 07:25:29 nrt Exp $
 */

#ifndef __BOOLEAN_H__
#define __BOOLEAN_H__

#ifndef FALSE
#define FALSE		0
#endif

#ifndef TRUE
#define TRUE		1
#endif

#ifndef boolean_t
#define boolean_t	int
#endif

#endif /* __BOOLEAN_H__ */
