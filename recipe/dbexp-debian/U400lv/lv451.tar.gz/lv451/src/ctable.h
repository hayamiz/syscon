/*
 * ctable.h
 *
 * All rights reserved. Copyright (C) 1996 by NARITA Tomio
 * $Id: ctable.h,v 1.3 2003/11/13 03:08:19 nrt Exp $
 */

#ifndef __CTABLE_H__
#define __CTABLE_H__

#include <ascii.h>
#include <ctable_t.h>
#include <ctable_e.h>

#endif /* __CTABLE_H__ */
