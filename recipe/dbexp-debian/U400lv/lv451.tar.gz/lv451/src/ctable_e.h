/*
 * ctable_e.h
 *
 * All rights reserved. Copyright (C) 1996 by NARITA Tomio
 * $Id: ctable_e.h,v 1.3 2003/11/13 03:08:19 nrt Exp $
 */

#ifndef __CTABLE_E_H__
#define __CTABLE_E_H__

extern c_table_t cTable[];

#endif /* __CTABLE_E_H__ */
