#! /usr/local/bin/perl -p
s/\r\n/\n/g
