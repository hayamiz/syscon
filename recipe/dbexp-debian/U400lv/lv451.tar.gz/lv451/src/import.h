/*
 * import.h
 *
 * All rights reserved. Copyright (C) 1996 by NARITA Tomio
 * $Id: import.h,v 1.4 2003/11/13 03:08:19 nrt Exp $
 */

#ifndef __IMPORT_H__
#define __IMPORT_H__

#include <boolean.h>

#define public   extern
#define private  static

#define byte	unsigned char

#endif /* __IMPORT_H__ */
