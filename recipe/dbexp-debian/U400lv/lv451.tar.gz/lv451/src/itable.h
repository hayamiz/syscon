/*
 * itable.h
 *
 * All rights reserved. Copyright (C) 1996 by NARITA Tomio
 * $Id: itable.h,v 1.3 2003/11/13 03:08:19 nrt Exp $
 */

#ifndef __ITABLE_H__
#define __ITABLE_H__

#include <itable_t.h>
#include <itable_e.h>

#endif /* __ITABLE_H__ */
