/*
 * itable_e.h
 *
 * All rights reserved. Copyright (C) 1996 by NARITA Tomio
 * $Id: itable_e.h,v 1.3 2003/11/13 03:08:19 nrt Exp $
 */

#ifndef __ITABLE_E_H__
#define __ITABLE_E_H__

extern i_table_t iTable[];

#endif /* __ITABLE_E_H__ */
