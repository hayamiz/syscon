/*
 * kana.h
 *
 * All rights reserved. Copyright (C) 1996 by NARITA Tomio
 * $Id: kana.h,v 1.3 2003/11/13 03:08:19 nrt Exp $
 */

#ifndef __KANA_H__
#define __KANA_H__

#include <boolean.h>

public boolean_t kana_conv;

public void KanaX0201toX0208();

#endif /* __KANA_H__ */
