/*
 * str.h
 *
 * All rights reserved. Copyright (C) 1996 by NARITA Tomio
 * $Id: str.h,v 1.5 2003/11/13 03:08:19 nrt Exp $
 */

#ifndef __STR_H__
#define __STR_H__

#define STR_SIZE	1024	/* string logical maximum length */

typedef unsigned short	str_t;

#endif /* __STR_H__ */
