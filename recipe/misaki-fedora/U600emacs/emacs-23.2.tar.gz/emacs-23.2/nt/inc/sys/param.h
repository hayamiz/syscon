#ifndef _PARAM_H_
#define _PARAM_H_

/*
 * sys\param.h doesn't exist on NT, so we'll make one.
 */

#define NBPG 4096

#endif /* _PARAM_H_ */

/* arch-tag: b1d90296-ec38-4839-83bd-0ddfd2528435
   (do not change this comment) */
