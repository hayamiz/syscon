/* Fake unistd.h: config.h already provides most of the relevant things. */

/* arch-tag: 68600bcd-3097-4501-a559-551db3cdb9fd
   (do not change this comment) */
