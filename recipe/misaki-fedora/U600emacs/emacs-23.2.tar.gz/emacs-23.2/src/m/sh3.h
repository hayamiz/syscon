/* Machine description file for SuperH. */

#ifdef __BIG_ENDIAN__
# define WORDS_BIG_ENDIAN
#endif

#define NO_ARG_ARRAY

/* arch-tag: 1b01b84f-f044-4afa-aa4b-caa54ec38966
   (do not change this comment) */
