warn 'deprecated openssl/ssl use: require "openssl" instead of "openssl/ssl"'
require 'openssl'
